package com.example.om22

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
