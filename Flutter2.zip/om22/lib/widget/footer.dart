import 'package:flutter/material.dart';

class Footer extends StatelessWidget {
  const Footer({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 1400,
      height: 70,
      color: Color.fromRGBO(6, 21, 33, 0.8),
      child: Column(
        children: <Widget>[
          SizedBox(height: 15),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Borderer('Contact Us'),
              SizedBox(width: 60),
              Borderer('Privacy Policy'),
            ],
          ),
          Center(
            child: Text(
              '__________________________________________',
              style: TextStyle(color: Colors.white),
            ),
          ),
         
        ],
      ),
    );
  }
}

class Borderer extends StatelessWidget {
  final String title;
  const Borderer(this.title);
  @override
  Widget build(BuildContext context) {
    return Container(
        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
        child: Text(
          title,
          style: TextStyle(
              fontSize: 12, fontWeight: FontWeight.w400, color: Colors.white),
        ),
        decoration: BoxDecoration(
            border: Border.all(
              color: Colors.black,
            ),
            color: Color.fromRGBO(6, 21, 33, 0.8),
            borderRadius: BorderRadius.circular(2))
            );
  }
}
