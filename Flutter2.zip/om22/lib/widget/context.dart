import 'package:flutter/material.dart';

class Context extends StatelessWidget {
  const Context({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children:<Widget>[ 
         SizedBox(height:20),
          Text(
            'Dataset Name',
            style:TextStyle(fontSize:18,fontWeight: FontWeight.w600,)
          ),
          SizedBox(height:10),
          Container(
            height:40,
            width:600,
           decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(3),
          border: Border.all(
            color: Colors.black54,
          )
           ),
          ),

          SizedBox(height:30),
           Text(
            'List of Entities/Categories',
            style:TextStyle(fontSize:18,fontWeight: FontWeight.w600,)
          ),
          SizedBox(height:10),
          Container(
            height:40,
            width:600,
           decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(3),
          border: Border.all(
            color: Colors.black54,
          )
           ),
          ),

          SizedBox(height:30),
           Text(
            'Tagging Instruction',
            style:TextStyle(fontSize:18,fontWeight: FontWeight.w600,)
          ),
          SizedBox(height:10),
          Container(
            height:100,
            width:600,
           decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(3),
          border: Border.all(
            color: Colors.black54,
          )
           ),
          ),
          SizedBox(height:30),

          RaisedButton(
            child: Text('Submit',
            style:TextStyle(color: Colors.white),
            ),
            color: Colors.black,
            onPressed: () { 
           print('Submitted');
            },
            ),         
        ],
      ),
    );
    }
}