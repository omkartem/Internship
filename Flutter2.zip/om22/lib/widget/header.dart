import 'package:flutter/material.dart';

class Header extends StatelessWidget {
  const Header({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Color.fromRGBO(51, 153, 225, 3),
      width: 1400,
      height: 70,
      alignment: Alignment.center,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Row(
            children: <Widget>[
              SizedBox(width: 10),
              Icon(
                Icons.toc,
                color: Colors.white,
                size: 35,
              ),
              SizedBox(width: 15),
              Logo('  Logo  '),
              Text(
                '    Product A',
                style: TextStyle(fontSize: 23, color: Colors.white),
              ),
            ],
          ),
          Row(
            children: <Widget>[
              Text(
                'Documentation    Demo  ',
                style: TextStyle(fontSize: 15, color: Colors.white),
              ),
              Text(
                '   Hello,______     ',
                style: TextStyle(fontSize: 15, color: Colors.black),
              ),
              Icon(
                Icons.account_circle,
                size: 40,
                color: Colors.white,
              ),
              SizedBox(width: 20),
            ],
          ),
        ],
      ),
    );
  }
}

class Logo extends StatelessWidget {
  final String title;
  const Logo(this.title);
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text(
        title,
        style: TextStyle(
          fontSize: 22,
        ),
      ),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(20)),
    );
  }
}

class Document extends StatelessWidget {
  final String title;
  const Document(this.title);
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 22,
      width: 150,
      child: Text(
        title,
        style: TextStyle(fontSize: 15, color: Colors.white),
        textAlign: TextAlign.center,
      ),
      decoration: BoxDecoration(
        color: Color.fromRGBO(51, 153, 225, 3),
        borderRadius: BorderRadius.circular(5),
        border: Border.all(
          color: Colors.white,
        ),
      ),
    );
  }
}
