import 'package:flutter/material.dart';

class H1 extends StatelessWidget {
  const H1({Key key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 60,
        child: Column(
      children: <Widget>[
        SizedBox(height:10),
        Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Row(children: <Widget>[
                SizedBox(width:10),
                Icon(
                  Icons.home,
                  color: Colors.blue,
                  size: 30,
                ),
                SizedBox(width:10),
                Text('Home\t',
                    style: TextStyle(
                      fontSize: 23,
                      fontWeight: FontWeight.w600,
                    )),
              ]),
              Text('Create Dataset',
                  style: TextStyle(
                    fontSize: 23,
                    fontWeight: FontWeight.w600,
                  )),
                  Text('                      '),
            ]),
            SizedBox(height:10),
        Line(),
      ],
    ));
  }
}

class Line extends StatelessWidget {
  const Line({Key key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 1500,
      height: 1,
      decoration: BoxDecoration(
          border: Border.all(
        color: Colors.black,
      )),
    );
  }
}
