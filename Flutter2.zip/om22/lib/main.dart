import 'package:flutter/material.dart';
import 'widget/header.dart';
import 'widget/footer.dart';
import 'widget/context.dart';
import 'widget/h1.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home:Scaffold(
        body:Column(
          children:<Widget>[
            Header(),
            H1(),
            Context(),
            SizedBox(height:25),
            Footer(),
          ]
        )
      )
    );
  }
}

