import 'package:flutter/material.dart';

class Notes extends StatelessWidget {
  const Notes({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 200,
        width: 200,
        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
        child: Column(
          children: <Widget>[
           
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(
                  Icons.note,
                  color: Colors.blue,
                  size: 40,
                ),
                Text(' Notes',
                    style: TextStyle(fontSize: 16, color: Colors.black)),
              ],
            )
          ],
        ),
        decoration: BoxDecoration(
            border: Border.all(
              color: Colors.black38,
            ),
            color: Colors.white,
            borderRadius: BorderRadius.circular(2)));
  }
}
