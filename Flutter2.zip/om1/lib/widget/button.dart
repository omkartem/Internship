import 'package:flutter/material.dart';

class Button extends StatelessWidget {
  final String title;
  const Button(this.title);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 25,
      width: 100,
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
      child: Text(
        title,
        style: TextStyle(fontSize:13,fontWeight: FontWeight.w400,color:Colors.white),
        textAlign: TextAlign.center,
      ),
      decoration: BoxDecoration(
        color: Colors.blue,borderRadius:BorderRadius.circular(5)
      )
    );
  }
}