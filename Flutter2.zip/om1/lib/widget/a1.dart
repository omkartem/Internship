import 'package:flutter/material.dart';


class A1 extends StatelessWidget {
  final String title;
  A1(this.title);
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 24),
      child: Center(
        child: Text(
          title,
          textDirection: TextDirection.ltr,
          style: TextStyle(
            fontSize: 20,
            color: Color.fromRGBO(51, 153, 225, 3),
          ),
        ),
      ),
    );
  }
}
