import 'package:flutter/material.dart';

class Chat extends StatelessWidget {
  const Chat({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 30,
        width: 200,
        child: Row(
          children: <Widget>[
              SizedBox(width:10),
            Icon(
              Icons.chat,
              color: Colors.black,
            ),
            Text(
              ' Chat With Us ! ',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w400),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        decoration: BoxDecoration(
            border: Border.all(
              color: Colors.black38,
            ),
            color: Colors.white,
            borderRadius: BorderRadius.circular(8)));
  }
}
