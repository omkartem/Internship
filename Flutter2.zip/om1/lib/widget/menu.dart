import 'package:flutter/material.dart';
import 'package:om1/widget/a1.dart';
import 'package:om1/widget/button.dart';

class Menu extends StatelessWidget {
  const Menu({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 1100,
      height: 450,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
      child: Column(
        children: <Widget>[
          //Header1('     Dashboard'),
          //Line(),
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Icon(
                            Icons.home,
                            color: Colors.blue,
                          ),
                          SizedBox(width: 10),
                          Text(
                            'Home',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 20,
                              color: Color.fromRGBO(51, 153, 225, 3),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      Row(
                        children: <Widget>[
                          Icon(
                            Icons.info,
                            color: Colors.black,
                          ),
                          SizedBox(width: 10),
                          Text(
                            'Project',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.black,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      Row(
                        children: <Widget>[
                          Icon(
                            Icons.dehaze,
                            color: Colors.black,
                          ),
                          SizedBox(width: 10),
                          Text(
                            'Dataset',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.black,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      Row(
                        children: <Widget>[
                          Icon(
                            Icons.supervisor_account,
                            color: Colors.black,
                          ),
                          SizedBox(width: 10),
                          Text(
                            'Members',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.black,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),

                  Expanded(
                      flex: 4,
                      child: Column(children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Icon(
                              Icons.info_outline,
                              size: 35,
                              color: Colors.blue,
                            ),
                            A1('Project'),
                          ],
                        ),
                        Button('View Project'),
                        SizedBox(height: 10),
                        Button('Request Demo'),
                        Text(
                            '________________________________\n-> Manage Project'),
                      ])),

                  Expanded(
                      flex: 4,
                      child: Column(children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Icon(
                              Icons.dehaze,
                              size: 35,
                              color: Colors.blue,
                            ),
                            A1('Dataset'),
                          ],
                        ),
                        Button('See Dataset'),
                        SizedBox(height: 10),
                        Button('Request Demo'),
                        Text(
                            '________________________________\n-> Manage Dataset'),
                      ])),
                  //A1(),
                ],
              ),
              SizedBox(height:15),
              Row(
                children: <Widget>[
                  Text(
                    '              ',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 20,
                      color: Color.fromRGBO(51, 153, 225, 3),
                    ),
                  ),

                  Expanded(
                      flex: 4,
                      child: Column(children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Icon(
                              Icons.supervisor_account,
                              size: 35,
                              color: Colors.blue,
                            ),
                            A1(' Members'),
                          ],
                        ),
                        Button('View Member'),
                        SizedBox(height: 10),
                        Button('Add Member'),
                        Text(
                            '             ________________________________\n             -> Manage Member'),
                      ])),

                  Expanded(
                      flex: 4,
                      child: Column(children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Icon(
                              Icons.business_center,
                              size: 35,
                              color: Colors.blue,
                            ),
                            A1(' Services'),
                          ],
                        ),
                        Button('View services'),
                        SizedBox(height: 10),
                        Button('Request for API'),
                        Text('________________________________'),
                      ])),
                  //A1(),
                ],
              ),
            ],
          ),
        ],
      ),
      decoration: BoxDecoration(
        color: Colors.white,
      ),
    );
  }
}

