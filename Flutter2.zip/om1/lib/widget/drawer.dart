import 'package:flutter/material.dart';

class Drawerer extends StatelessWidget {
  const Drawerer({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
 drawer: Drawer(
          child: ListView(
                children: <Widget>[
                 UserAccountsDrawerHeader(
                   accountName: Text('Customer Name',style: 
                   TextStyle(
                     fontSize:19,fontWeight: FontWeight.w700),
                     textAlign: TextAlign.center,
                     ),
                  accountEmail: Text('omkartemgire12@gmail.com',),
                  ),
                 SizedBox(height:10),
                  Text(
                      'Menu',
                      style: TextStyle(fontSize: 25,color: Colors.blue),
                      textAlign: TextAlign.center,
                    ),
                  ListTile(
                    leading:Icon(Icons.home,color: Colors.blue,),
                    title: Text('Home',style:TextStyle(color: Colors.blue)),
                  ),
                  ListTile(
                    leading:Icon(Icons.info,color: Colors.blue,),
                    title: Text('Project',style:TextStyle(color: Colors.blue)),
                  ),
                  ListTile(
                    leading:Icon(Icons.dehaze,color: Colors.blue,),
                    title: Text('Dataset',style:TextStyle(color: Colors.blue)),
                  ),
                  ListTile(
                    leading:Icon(Icons.supervisor_account,color: Colors.blue,),
                    title: Text('Services',style:TextStyle(color: Colors.blue)),
                  ),
                ],
        ),
        ),
    );
  }
}