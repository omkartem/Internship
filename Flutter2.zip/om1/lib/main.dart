import 'package:flutter/material.dart';
import 'package:om1/widget/menu.dart';
import 'widget/footer.dart';
import 'widget/header.dart';
import 'widget/notes.dart';
import 'widget/chat.dart';
import 'commons/collapsing_navigation_drawer_widget.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Column(
          children: <Widget>[
            Header(),
            SizedBox(height: 10),
            Header1('                                Dashboard'),
            Line(),
            Row(
              children: <Widget>[
                //CollapsingNavigationDrawer(),
                Menu(),
                Column(
                  children: <Widget>[
                    Notes(),
                    SizedBox(height: 25),
                    Chat(),
                  ],
                ),
              ],
            ),
            SizedBox(height: 15),
            Footer(),
          ],
        ),
      ),
    );
  }
}

class Header1 extends StatelessWidget {
  final String title;
  const Header1(this.title);
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      width: 1500,
      child: Text(
        title,
        style: TextStyle(fontWeight: FontWeight.w800, fontSize: 20),
        textAlign: TextAlign.left,
      ),
      //decoration: BoxDecoration(border: Border.all(color: Colors.white)),
    );
  }
}

class Line extends StatelessWidget {
  const Line({Key key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 1.0,
      width: 1500.0,
      color: Colors.black,
    );
  }
}
