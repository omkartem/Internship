import 'package:flutter/material.dart';

class NavigationModel {
  String title;
  IconData icon;

  NavigationModel({this.title, this.icon});
}

List<NavigationModel> navigationItems = [
  NavigationModel(title: "Home", icon: Icons.home),
  NavigationModel(title: "Dataset", icon: Icons.dehaze),
  NavigationModel(title: "Members", icon: Icons.supervisor_account),
  //NavigationModel(title: "Services", icon: Icons.),
  NavigationModel(title: "Notes", icon: Icons.note),
];